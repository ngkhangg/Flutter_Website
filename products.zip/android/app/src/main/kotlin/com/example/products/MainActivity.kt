package com.example.products

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
